import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.*;
import javax.swing.text.Element;
import javax.swing.undo.UndoManager;


public class editor extends JFrame
{
    JTextArea area=new JTextArea(0,0);
    JScrollPane scroller=new JScrollPane(area);
    
    public JPopupMenu pop=new JPopupMenu();
    JMenu menu=new JMenu("Edit");
    JMenuItem menuitem=new JMenuItem("Edit");
    JMenuItem menucut=new JMenuItem("cut");
    JMenuItem menuclear=new JMenuItem("clear");
    JMenuItem menupast=new JMenuItem("paste");
    
    JToolBar toolbar=new JToolBar();
    
    JButton newfile=new JButton(new ImageIcon("new.jpg"));
    
    JButton openfile=new JButton(new ImageIcon("open.jpg"));
    JButton savefile=new JButton(new ImageIcon("save.jpg"));
    
    JButton cutfile=new JButton(new ImageIcon("cut.jpg"));
    JButton copyfile=new JButton(new ImageIcon("copy.jpg"));
    JButton pastefile=new JButton(new ImageIcon("paste.jpg"));
    
    JMenuBar menubar=new JMenuBar();
    
    JMenu file=new JMenu("file");
    JMenu edit=new JMenu("edit");
    JMenu format=new JMenu("format");
    JMenu view=new JMenu("view");
    JMenu HELP=new JMenu("help");
    
    JMenuItem NEWFILE =new JMenuItem("New",new ImageIcon("new.jpg"));
    JMenuItem OPENFILE =new JMenuItem("Open",new ImageIcon("open.jpg"));
    JMenuItem SAVEFILE =new JMenuItem("Save",new ImageIcon("save.jpg"));
    JMenuItem SAVEASFILE=new JMenuItem("Saveas",new ImageIcon("saveas..."));
    JMenuItem EXITFILE=new JMenuItem("Exit",new ImageIcon("exit.jpg"));
    
    JMenuItem UNDOEDIT=new JMenuItem("Undo");
    JMenuItem REDOEDIT=new JMenuItem("Redo");
    JMenuItem COPYEDIT=new JMenuItem("Copy");
    JMenuItem CUTEDIT=new JMenuItem("Cut");
    JMenuItem PASTEDIT=new JMenuItem("Past");
    JMenuItem DELETEDIT=new JMenuItem("Delete");
    JMenuItem FINDEDIT=new JMenuItem("Fint");
    JMenuItem FINDNEXTEDIT=new JMenuItem("Find Next");
    JMenuItem REPLACEDIT=new JMenuItem("Replace");
    JMenuItem GOTOEDIT=new JMenuItem("Go To");
    JMenuItem SELECTEDIT=new JMenuItem("Select All");
    JMenuItem TIMEDIT=new JMenuItem("Time/Date");
    
    JCheckBoxMenuItem WORDFORMAT= new JCheckBoxMenuItem("Word Wrap");
    JMenuItem FONT=new JMenuItem("Font");
    
    JCheckBoxMenuItem STATUSVIEW= new JCheckBoxMenuItem("Status bar");
    JMenuItem ABOUT=new JMenuItem("About");
    
    
    String FILE=null;
    String fileN;
    
    boolean opened=false;
    
    JPanel statusPanel=new JPanel();
    
    JLabel statusLabel;
    
    JPanel aboutPanel=new JPanel();
    
    int ind=0;
    
    StringBuffer sbufer;
    String findstring;
    
    FontSelector fontS=new FontSelector();
    
    UndoManager undo=new UndoManager();
    UndoAction undoaction=new UndoAction();
    RedoAction redoaction=new RedoAction();
    
    
    public editor()
    {
    	super("MY NOTEPAD");
    	this.setSize(800,600);
    	
    	this.getContentPane().setLayout(new BorderLayout());
    	
    	area.setLineWrap(true);
    	
    	area.requestFocus(true);
    	
    	this.getContentPane().add(scroller, BorderLayout.CENTER);
    	
    	this.getContentPane().add(statusPanel, BorderLayout.SOUTH);
    	
    	area.setDragEnabled(true);
    	
    	toolbar.setFloatable(false);
    	
    	this.getContentPane().add(toolbar, BorderLayout.NORTH);
    	
    	area.addMouseListener(popupListener);
    	
    	area.getDocument().addUndoableEditListener(new MyUndoableEditListener());
    	
    	file.add(NEWFILE);
    	file.add(OPENFILE);
    	file.add(SAVEFILE);
    	file.add(SAVEASFILE);
    	file.addSeparator();
    	file.addSeparator();
    	file.add(EXITFILE);
    	
    	edit.add(undoAction);
    	edit.add(redoAction);
    	edit.add(CUTEDIT);
    	edit.add(COPYEDIT);
    	edit.add(PASTEDIT);
    	edit.add(DELETEDIT);
    	edit.addSeparator();
    	edit.add(FINDEDIT);
    	edit.add(FINDNEXTEDIT);
    	edit.add(REPLACEDIT);
    	edit.add(GOTOEDIT);
    	edit.addSeparator();
    	edit.add(SELECTEDIT);
    	edit.add(TIMEDIT);
    	
    	format.add(WORDFORMAT);
    	WORDFORMAT.setSelected(true);
    	format.add(FONT);
    	
    	view.add(STATUSVIEW);
    	STATUSVIEW.setSelected(true);
    	
    	HELP.add(ABOUT);
    	
    	file.setMnemonic(KeyEvent.VK_F);
    	menubar.add(file);
    	edit.setMnemonic(KeyEvent.VK_E);
    	menubar.add(edit);
    	format.setMnemonic(KeyEvent.VK_T);
    	menubar.add(format);
    	view.setMnemonic(KeyEvent.VK_V);
    	menubar.add(view);
    	HELP.setMnemonic(KeyEvent.VK_H);
    	menubar.add(HELP);
    	
        this.setJMenuBar(menubar);
    	
    	pop.add(undoAction);
    	pop.add(redoAction);
    	pop.addSeparator();
    	pop.add(menuitem);
    	pop.add(menucut);
    	pop.add(menupast);
    	pop.add(menuclear);
    	
    	newfile.setBorder(null);
    	openfile.setBorder(null);
    	savefile.setBorder(null);
    	SAVEASFILE.setBorder(null);
    	cutfile.setBorder(null);
    	copyfile.setBorder(null);
    	pastefile.setBorder(null);
    	
    	
    	toolbar.add(newfile);
    	newfile.setToolTipText("New File");
    	toolbar.addSeparator();
    	toolbar.add(openfile);
    	openfile.setToolTipText("open file");
    	toolbar.addSeparator();
    	toolbar.add(savefile);
    	savefile.setToolTipText("save file");
    	toolbar.addSeparator();
    	toolbar.add(cutfile);
    	cutfile.setToolTipText("cutfile");
    	toolbar.addSeparator();
    	toolbar.add(copyfile);
    	copyfile.setToolTipText("copy");
    	toolbar.addSeparator();
    	toolbar.add(pastefile);
    	pastefile.setToolTipText("paste");
    	
    	newfile.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				opened=false;
				if(area.getText().equals(""))
				{
					System.out.print("test is empty");
				}
				else
				{
					int confirm=JOptionPane.showConfirmDialog(null,"Would you like to save?","New File",JOptionPane.YES_NO_CANCEL_OPTION);
					if(confirm==JOptionPane.YES_OPTION)
					{
						saveFile();
						area.setText(null);
						statusPanel.removeAll();
						statusPanel.validate();
					}
				}
			}
		});
    	
    	openFile.addActionListener(new ActionListener() 
    			{
    		          public void actionPerformed(ActionEvent e)
    		          {
    		        	  openFile();
    		          }
    			});
    	
    	saveFile.addActionListener(new ActionListener() 
		{
	          public void actionPerformed(ActionEvent e)
	          {
	        	  saveFile();
	          }
		});
    	
    	cutFile.addActionListener(new ActionListener() 
		{
	          public void actionPerformed(ActionEvent e)
	          {
	        	 area.cut();
	          }
		});
					
    	copyFile.addActionListener(new ActionListener() 
		{
	          public void actionPerformed(ActionEvent e)
	          {
	        	  area.copy();
	          }
		});
    	
    	pastefile.addActionListener(new ActionListener() 
		{
	          public void actionPerformed(ActionEvent e)
	          {
	        	  area.paste();
	          }
		});
    	
    	
    	menuitem.addActionListener(new ActionListener()
    			{
    		     public void actionPerformed(ActionEvent e)
    		     {
    		    	 area.copy();
    		    	 menupast.setEnabled(true);
    		    	 pastefile.setEnabled(true);
    		    	 PASTEDIT.setEnabled(true);
    		     }
    			});
    	
    	
    	menucut.addActionListener(new ActionListener()
		{
	     public void actionPerformed(ActionEvent e)
	     {
	    	 area.cut();
	    	 menupast.setEnabled(true);
	    	 pastefile.setEnabled(true);
	    	 PASTEDIT.setEnabled(true);
	     }
		});
    	
    	menupaste.addActionListener(new ActionListener()
		{
	     public void actionPerformed(ActionEvent e)
	     {
	    	 area.paste();
	    	 menupaste.setEnabled(true);
	    	 pastefile.setEnabled(true);
	    	 PASTEDIT.setEnabled(true);
	     }
		});
    	
    		
    	menuclear.addActionListener(new ActionListener()
		{
	     public void actionPerformed(ActionEvent e)
	     {
	    	 area.setText(null);
	    	 
	     }
		});
    	
    	NEWFILE.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N,ActionEvent.CTRL_MASK));
    	  NEWFILE.addActionListener(new ActionListener ()
    	  {
    		    public void actionPerformed(ActionEvent e)
    		    {
    		    	opened=false;
    		    	int confirm= JOptionPane.showConfirmDialog(null,"would you like to save?","New File",JOptionPane.YES_NO_CANCEL_OPTION);
    		    	if(confirm==JOptionPane.YES_OPTION)
    		    	{
    		    		saveFile();
    		    		area.setText(null);
    		    		statusPanel.removeAll();
    		    		statusPanel.validate();
    		    	}
    		    }
    	  });
      	 
    	SAVEFILE.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,ActionEvent.CTRL_MASK));
    	SAVEFILE.addActionListener(new ActionListener()
    			{
    	          public void actionPerformed(ActionEvent e)
    	          {
    	        	  saveFile();
    	        	 
    	          }   		     
    			});
    	
    	SAVEFILE.addActionListener(new ActionListener()
    			{
    		      public void actionPerformed(ActionEvent e)
    		      {
    		    	  opened = false;
    		    	  saveFile();
    		    	  
    		      }
    		   
    			});
    
    	SELECTEDIT.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A,ActionEvent.CTRL_MASK));
    	SAVEFILE.addActionListener(new ActionListener()
    			{
    	          public void actionPerformed(ActionEvent e)
    	          {
    	        	 area.selectAll();
    	        	 
    	          }   		     
    			});
     
    	STATUSVIEW.addActionListener(new ActionListener()
		{
	      public void actionPerformed(ActionEvent e)
	      {
               if(STATUSVIEW.isSelected())
            	   statusPanel.setVisible(true);
               else
            	   statusPanel.setVisible(false);
         
	      }
	      
		}); 
    
    	
    	OPENFILE.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O,ActionEvent.CTRL_MASK));
    	OPENFILE.addActionListener(new ActionListener()
    			{
    	          public void actionPerformed(ActionEvent e)
    	          {
    	        	 openFile();
    	        	 
    	          }   		     
    			});
       
    	
    	CUTEDIT.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X,ActionEvent.CTRL_MASK));
    	CUTEDIT.addActionListener(new ActionListener()
    			{
    	          public void actionPerformed(ActionEvent e)
    	          {
    	        	 area.cut();
    	        	 
    	          }   		     
    			});
       
    
    	COPYEDIT.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C,ActionEvent.CTRL_MASK));
    	COPYEDIT.addActionListener(new ActionListener()
    			{
    	          public void actionPerformed(ActionEvent e)
    	          {
    	        	 area.copy();
    	        	 
    	          }   		     
    			});
       
    	PASTEDIT.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V,ActionEvent.CTRL_MASK));
    	PASTEDIT.addActionListener(new ActionListener()
    			{
    	          public void actionPerformed(ActionEvent e)
    	          {
    	        	 area.paste();
    	        	 
    	          }   		     
    			});
       
    
    	FONT.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F,ActionEvent.CTRL_MASK));
    	FONT.addActionListener(new ActionListener()
    			{
    	          public void actionPerformed(ActionEvent e)
    	          {
    	        	 fontS.setVisible(true);
    	        	 fontS.okButton.addActionListener(new ActionListener()
    	        			 {
    	        		     public void actionPerformed(ActionEvent ae)
    	        		     {
    	        		    	 Font selectedFont=fontS.returnFont();
    	        		    	 area.setFont(selectedFont);
    	        		    	 fontS.setVisible(false);
    	        		     }
    	        		     
    	        			});
    	        	 
    	        	 fontS.cancelButton.addActionListener(new ActionListener()
    	        			 {
    	        		       public void actionPerformed(ActionEvent ae)
    	    	                {
    	    	        	      fontS.setVisible(false);
    	    	        	 
    	    	                } 
    	        			 });
    	          }   		     
    			});
    	
    	TIMEDIT.addActionListener(new ActionListener()
		{
          public void actionPerformed(ActionEvent e)
          {
            
        	   Date currentDate;
        	   SimpleDateFormat formatter;
        	   String dd;
        	   formatter = new SimpleDateFormat("KK:mm aa MMMMMMMM dd yyyy", Locale.getDefault());
        	     currentDate = new java.util.Date();
        	     dd = formatter.format(currentDate);
        	     area.insert(dd,area.getCaretPosition());
        	     
          }
		});
    	
    	FINDEDIT.addActionListener(new ActionListener()
		{
          public void actionPerformed(ActionEvent e)
          {
           
            try
            {
            	sbufer = new StringBuffer(area.getText());
            	findString = JOptionPane.showInputDialog(null,"Find");
            	
            			ind = sbufer.indexOf(findString);
            	        area.setCaretPosition(ind);
            	        area.setSelectionStart(ind);
            	        area.setSelectionEnd(ind+findString.length());
            			
            }
    
          catch(IllegalArgumentException npe)
            {
        	  JOptionPane.showMessageDialog(null,"String not found");
        	  
            }
          catch(NullPointerException nfe){}
          }
		});
    	
    	FINDNEXTEDIT.addActionListener(new ActionListener()
		{
          public void actionPerformed(ActionEvent e)
          {
    	
    	    try
    	    {
    	    	sbufer = new StringBuffer(area.getText());
    	    	findString = JOptionPane.showInputDialog(null,"Find");
    	    	ind = sbufer.indexOf(findString,area.getCaretPosition());
    	    	
    	    	area.setCaretPosition(ind);
    	    	area.setSelectionStart(ind);
    	    	area.setSelectionEnd(ind+findString.length());
    	    	
    	    }
    	   
    	    catch(IllegalArgumentException nfe)
    	    {
    	    	JOptionPane.showMessageDialog(null,"String not found");
    	    	
    	    }
    	    catch(NullPointerException nfe){}
          }
		});
    	
    	
    	EXITFILE.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E,ActionEvent.CTRL_MASK));
    	EXITFILE.addActionListener(new ActionListener()
    			{
    	          public void actionPerformed(ActionEvent e)
    	          {
    	        	 int confirm = JOptionPane.showConfirmDialog(null,"Would you like to save?","Exit Application",JOptionPane.YES_NO_CANCEL_OPTION);
    	        	
    	        	 if(confirm == JOptionPane.YES_OPTION)
    	        	 {
    	        		 savefile();
    	        		 dispose();
    	        		 System.exit(0);
    	        	 }
    	        	 else
    	        		if(confirm == JOptionPane.CANCEL_OPTION)
    	            		     {}
    	        		else
    	        		{
    	        			dispose();
    	        			System.exit(0);
    	        		}
    	          }
    			});
               
    	REPLACEDIT.addActionListener(new ActionListener()
		{
          public void actionPerformed(ActionEvent e)
          {
           
            try
            {
            	
            	String replace = JOptionPane.showInputDialog(null,"Replace");
                area.replaceSelection(replace);
            }
    
          catch(NumberFormatException nfe)
            {}
          }
		});
    	GOTOEDIT.addActionListener(new ActionListener()
		{
          public void actionPerformed(ActionEvent e)
          {
           
            try
            {
            	Element root = area.getDocument().getDefaultRootElement();
            	Element paragraph = root.getElement(Integer.parseInt(JOptionPane.showInputDialog(null,"Go to line")));
            	
            	area.setCaretPosition(paragraph.getStartOffset()-1);
            }
    
          catch(NullPointerException npe)
            {
        	  JOptionPane.showMessageDialog(null,"Invalid line number");
        	  
            }
          catch(NumberFormatException nfe){}
          }
		});	
    FINDNEXTEDIT.addActionListener(new ActionListener()
    		{
    	     public void actionPerformed(ActionEvent e)
    	     {
    	    	 try
    	    	 {
    	    		 sbufer=new StringBuffer(area.getText());
    	    		 findString=JOptionPane.showInputDialog(null,"Find");
    	    		 ind=sbufer.indexOf(findString,area.getCaretPosition());
    	    		 area.setCaretPosition(ind);
    	    		 area.setSelectionStart(ind);
    	    		 area.setSelectionEnd(ind+findString.length());
    	    	 }
    	    	 catch(IllegalArgumentException npe)
    	    	 {
    	    		 JOptionPane.showMessageDialog(null,"String not found");
    	    	 }
    	    	 catch(NullPointerException nfe){}
    	     }
    		});
     
      FINDNEXTEDIT.addActionListener(new ActionListener()
    		  {
    	       public void actionPerformed(ActionEvent e)
    	       {
    	    	   try
    	    	   {
    	    		    sbufer=new StringBuffer(area.getText());
       	    		 findString=JOptionPane.showInputDialog(null,"Find");
       	    		 ind=sbufer.indexOf(findString,area.getCaretPosition());
       	    		 area.setCaretPosition(ind);
       	    		 area.setSelectionStart(ind);
       	    		 area.setSelectionEnd(ind+findString.length());
       	    	 }
       	    	 catch(IllegalArgumentException npe)
       	    	 {
       	    		 JOptionPane.showMessageDialog(null,"String not found");
       	    	 }
       	    	 catch(NullPointerException nfe){}
    	    	   }
    	       });
      
      EXITFILE.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, ActionEvent.CTRL_MASK));
       EXITFILE.addActionListener(new ActionListener()
    		   {
    	         public void actionPerformed(ActionEvent e)
    	         {
    	        	 int confirm=JOptionPane.showConfirmDialog(null, "Would you like to save?","Exit Application",JOptionPane.YES_NO_CANCEL_OPTION);
    	        	 if(confirm==JOptionPane.YES_OPTION)
    	        	 {
    	        		 saveFile();
    	        		 dispose();
    	        		 System.exit(0);
    	        	 }
    	        	 else
    	        		 if(confirm==JOptionPane.CANCEL_OPTION){}
    	        		 else
    	        		 {
    	        			 dispose();
    	        			 System.exit(0);
    	        		 }
    	         }
    		   });
       
       REPLACEDIT.addActionListener(new ActionListener()
    		   {
    	   public void actionPerformed(ActionEvent e)
    	   {
    		   try
    		   {
    			   String replace=JOptionPane.showInputDialog(null,"Replace");
    			   area.replaceSelection(replace);
    		   }
    		   catch(NumberFormatException nfe){}
    	   }
    		   });
       
       GOTOEDIT.addActionListener(new ActionListener()
    		   {
    	   public void actionPerformed(ActionEvent e)
    	   {
    		   try
    		   {
    			   Element root=area.getDocument().getDefaultRootElement();
    			   Element paragraph=root.getElement(Integer.parseInt(JOptionPane.showInputDialog(null,"Go To line")));
    			    area.setCaretPosition(paragraph.getStartOffset()-1);
    		   }
    		   catch(NullPointerException npe)
    		   {
    			   JOptionPane.showMessageDialog(null, "Invalid line number");
    		   }
    		   catch(NumberFormatException nfe){}
    	   }
    		   });
    		  
    
   DELETEDIT.addActionListener(new ActionListener()
{
  public void actionPerformed(ActionEvent e)
   {
     area.replaceSelection(null);
   }
});

//Sets the linewrap to true or false
WORDFORMAT.addActionListener(new ActionListener()
{
  public void actionPerformed(ActionEvent e)
   {
     if(WORDFORMAT.isSelected())
     area.setLineWrap(true);
      else
      area.setLineWrap(false);
   }
});
 
//about
ABOUT.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F2,ActionEvent.CTRL_MASK));
 ABOUT.addActionListener(new ActionListener()
  {
   public void actionPerformed(ActionEvent e)
   {
    String message="Sample application using the simple text editor component\n"+"Develpoed by:"+" Rishi Kumar Gandhi\n"+"Manish Agarwal";
        JOptionPane.showMessageDialog(aboutPanel, message);
   }
  });

 //close the window when the close button is pressed 
  addWindowListener(new WindowListener()
{
  public void windowClosing(WindowEvent e)
   {
     int confirm=JOptionPane.showConfirmDialog(null,"Would you like to save?","Exit application",JOptionPane.YES_NO_CANCEL_OPTION);
      if(confirm==JOptionPane.YES_OPTION)
        {
         saveFile();
         dispose();
        System.exit(0);
        }
       else
       if(confirm==JOptionPane.CANCEL_OPTION)
        {
         
        }
       else
       {
          dispose();
        System.exit(0);
      }
   }
});
 }

  //main function
 public static void main(String[] args)
{
 editor l=new editor();
 l.setVisible(true);
}

//function called by the save button
  public void saveFile()
  {
   String line=area.getText();
if(opened==true)
{
  try
   {
    FileWriter output= new FileWriter(file);
    BufferedWriter bufout=new BufferWriter(output);
    bufout.write(line,0,line.length());
    JOptionPane.showMessageDialog(null,"Save Successful");
    bufout.close();
    output.close();
   }
   catch(IOException ioe)
     {
      ioe.printStackTrace();
     }
}
else
{
  JFileChooser fc=new JFileChooser();
  int result =fc.showSaveDialog(new JPanel());
  if(result ==JFileChooser.APPROVE_OPTION)
  {
   fileN = String.valueOf(fc.getSelectedFile());
   try
   {
    FileWriter output=new FileWriter(fileN);
    BufferedWriter bufout= new BufferedWriter(output);
    bufout.write(line,0,line.length());
    JOptionPanel.showMessageDialog(null,"Save Successful");
    bufout.close();
    output.close();
    opened = true;
   }
   catch(IOException ioe)
   {
    ioe.printStackTrace();
   }
  } 
}
  
//FUNCTION TO OPEN FILE
  public void openFile()
  {
   status.Panel.removeAll();
   status.Panel.validate();
   area.setText(null);
   JFileChooser fc = new JFileChooser();
   int result = fc.showOpenDialog(new JPanel());
   if(result==JFileChooser.APPROVE_OPTION)
{
   String file=String.valueof(fc.getSelectedFile());
  File fil=new File(file);
   newFile.setEnabled(false);
  Thread loader=new FileLoader(fil,area.getDocument());
  loader.start();
  statusPanel.removeAll();
   statusPanel.revalidate();
  }
else{}
}
//class for the mouselistener
 
 class PopupListener extends MouseAdapter
  {
   public void mousePressed(MouseEvent e)
   {
    maybeShowPopup(e);
   }
  public void mouseReleased(MouseEvent e)
   {
    maybeShowPopup(e);
   }
    
   private void maybeShowPopup(MouseEvent e)
  {
    if(e.isPopupTrigger())
     {
     pop.show(e.getComponent(),e.getX(),e.getY());
     }
   }
  }

//class for undolistener
 
  public class MyUndoableEditListener implements UndoableEditListener
  {
   public void undoableEditHappened(UnoableEditEvent e)
  {
    undo.addEdit(e.getEdit());
    undoAction.update();
    redoAction.update();
   }
  }

  //thread to laod a file

  class FileLoader extends Thread
  {
   JLabel state;
   FileLoader(File f,Document doc)
   {
    setPriority(4);
    this.f=f;
    this.doc=doc;
  }
 
   public void run()
   {
    try{
    statusPanel.removAll();
    JProgressBar progress=new JProgressBar();
    progress.setMinimum(0);
    progress.setMaximum((int)f.length());
    statusPanel.add(new JLabel("opened so far"));
    statusPanel.add(progress);
    statusPanel.revalidate();

    Reader in=new FileReader(f);
  char[] buff=new char[4096];
  int nch;
   while((nch=in.read(buff,0,buff.length))!=-1)
  {
   doc.insertString(doc.getLength(),new String(buff,0,nch),null);
   progress.setValue(progress.getValue()+nch);
  }
   
   statusPanel.removeAll();
   statusPanel.revalidate();
  }
  
   catch(IOException)
   {
     System.err.println(e.toString());
   }
   catch(BadLocationException e)
   {
    System.err.println(e.getMessage());
   }
    newFile.setEnabled(true);
   }
   Document doc;
   File f;
  }

 //undo and redo classes
 
  class UndoAction extends AbstractAction
  {
   public undoAction()
  {
   super("Undo");
  setEnabled(false);
  }
 
   public void actionPerformed(ActionEvent e)
   {
    try
    {
     undo.undo();
    }
    catch(CannotUndoException ex)
    {
     System.out.println("Unable to undo:"+ ex);
     ex.printStackTrace();
    }
     
     update();
     redoAction.update();
   }
    protected void update()
   {
    if(undo.canUndo())
    {  
      setEnabled(true);
	  putValue("Undo",undo.getUndoPresentationName());
	}
	else
	{
	 setEnabled(false);
	 putValue(Action.NAME,"Undo");
	}
   }
 }
   class RedoAction extends AbstractAction
  {
   public RedoAction()
  {
   super("Redo");
  setEnabled(false);
  }
  
     public void actionPerformed(ActionEvent e)
   {
    try
    {
     undo.redo();
    }
    catch(CannotRedoException ex)
    {
     System.out.println("Unable to redo:"+ ex);
     ex.printStackTrace();
    }
     
     update();
     undoAction.update();
     protected void update()
   {
    if(undo.canRedo())
    {  
      setEnabled(true);
	  putValue("Redo",undo.getRedoPresentationName());
	}
	else
	{
    setEnabled(false);
	 putValue(Action.NAME,"Redo");
	}
   }
 }
    
	}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}


}
